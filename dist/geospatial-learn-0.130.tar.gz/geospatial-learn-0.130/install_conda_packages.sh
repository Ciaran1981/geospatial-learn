#!/bin/bash
#

conda install glob2 matplotlib more-itertools numpy pandas psutil scikit-image scikit-learn scipy gdal tqdm
